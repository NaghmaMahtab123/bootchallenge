import java.io.*;
class Person
{
	int age;
	String name;
	void read() throws IOException
	{
		System.out.println("Enter name and age of the person: " );
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		name = br.readLine();
		age = Integer.parseInt(br.readLine());
	}
	void method()
	{
		if(age  < 25 )
			System.out.println(name +" is YOUNG");
		else if(age >=25 && age <=40)
			System.out.println(name +" is MIDDLE");
		else
			System.out.println(name+ " is OLD AGED");
	}
}
class PersonDemo
{
	public static void main(String args[]) throws IOException
	{
		Person p = new Person();
		p.read();
		p.method();
	}
}