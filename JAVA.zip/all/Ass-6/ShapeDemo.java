import java.io.*;
class Shape
{
	float length, width,side;
	void area() throws IOException
	{
		System.out.print("Area is : ");
	}
}
class Square extends Shape
{
	void area() throws IOException
	{
		System.out.println("Enter side of the square: ");
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		side = Float.parseFloat(br.readLine());
		super.area();
		System.out.println(side*side);
	}
}
class Rectangle extends Shape
{
	void area() throws IOException
	{
		System.out.println("Enter length and width of rectangle: ");
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		length = Float.parseFloat(br.readLine());
		width = Float.parseFloat(br.readLine());
		super.area();
		System.out.println(length*width);
	}
}
class ShapeDemo
{
	public static void main(String args[]) throws IOException
	{
		Square s = new Square();
		s.area();
		Rectangle r = new Rectangle();
		r.area();
	}
}
		