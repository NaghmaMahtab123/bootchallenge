import java.io.*;
class Account
{
	int accNo;
	String acHoldName;
	float balance, amount;
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);
	Account(int ano, String name, float amt)
	{
		accNo= ano;
		acHoldName = name;
		balance = amt;
	}
	void withdraw() throws IOException
	{
		System.out.println("Enter amount to be withdraw : ");
		amount = Float.parseFloat(br.readLine());
		if (balance  >amount)
		{
			balance = balance - amount;
			System.out.println("Rs./- " + amount + " has been withdrawn successfully.");
			System.out.println("Your current balance is : " + balance);
		}
		else
			System.out.println("Insufficient balance in account."); 
	}
	void deposit() throws IOException
	{
		System.out.println("Enter amount to be deposited : ");
		amount = Float.parseFloat(br.readLine());
		balance = balance + amount;
		System.out.println("Rs./- " + amount + " has been successfully deposited.");
		System.out.println("Your current balance is : " + balance);
	}
}
class AccountMain
{
	public static void main(String args[]) throws IOException
	{
		int choice;
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		Account ac = new Account(10004365, "Sagar", 35000.00f);
		do
		{
		System.out.println("\t\t###Account Menu###");
		System.out.println("\t\t----------------------------");
		System.out.println("1.Withdraw");
		System.out.println("2.Deposit");
		System.out.println("Enter your choice...");
		choice = Integer.parseInt(br.readLine());
		switch(choice)
		{
			case 1:
			ac.withdraw();
			break;
			case 2:
			ac.deposit();
			break;
			case 3:
			System.exit(0);
		}
		}while(choice!=3);
	}
}