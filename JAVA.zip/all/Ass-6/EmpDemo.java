import java.io.*;
class Employee
{
	int empId;
	String empName;
	float basicSal, hra, da, pf, gross, net;
	void read() throws IOException 
	{
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br =new BufferedReader(in);
		System.out.println("Enter employee id, name and basic salary: ");
		empId = Integer.parseInt(br.readLine());
		empName = br.readLine();
		basicSal = Float.parseFloat(br.readLine());
	}
	void calculate()
	{
		hra = basicSal*.15f;
		da = basicSal*.10f;
		pf = basicSal*.08f;
		gross = basicSal + da + hra;
		net = gross - pf;
	}
	void show()
	{
		System.out.println("Employee Id: "+empId);
		System.out.println("Employee name: "+empName);
		System.out.println("Basic Salary : "+basicSal);
		System.out.println("HRA : "+hra);
		System.out.println("DA : "+da);
		System.out.println("Gross Salary: "+gross);
		System.out.println("PF : "+pf);
		System.out.println("Net Salary : "+net);
	}
}
class EmpDemo
{
	public static void main(String args[]) throws IOException
	{
		Employee e = new Employee();
		e.read();
		e.calculate();
		e.show();
	}
}
