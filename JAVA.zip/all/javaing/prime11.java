import java.io.*;
class B
{
	int n,l,i,m;
	public void input() throws IOException
	{
			BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("enter the no.=");
			n=Integer.parseInt(in.readLine());
			m=n;
			for(i=1;i<=n;i++)
			{
				if(n%i==0)
				{
					l=l+1;
				}
			}
			if(l==2)
			System.out.println("no. is prime");
			else
			System.out.println("no. is not prime");
		
	}
}
class prime11
{
		public static void main(String args[]) throws IOException
		{
			BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
			B obj1=new B();
			obj1.input();
			
		}
}
