class A extends Thread
{
	public void run()
	{
		synchronized void disp()
		{
			System.out.println("CLASS A METHOD DISP");
		}
		synchronized void disp1();

	}
}

class demo
{
	public static void main(String args[]) 
	{
		A obj=new A();
		obj.start();
	}
}