class x implements Runnable
{
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println("THREAD X : "+i);
		}
		System.out.println("END IF THREAD X");
	}
}

class test
{
	public static void main(String args[])
	{
		x runnable =new x();
		Thread threadx=new Thread(runnable);
		threadx.start();
		System.out.println("END OF MAIN THREAD");
	}
}