class A
{
	int a,b;
	public void cal()
	{
		int s=a+b;
		System.out.println("sum of two nos="+s);
	}
	
}
class add
{
	public static void main(String args[])
	{
		A obj=new A();
		obj.a=5;
		obj.b=8;
		obj.cal();
	}
}