import java.io.*;
class A1
{
	int a,b;
	A1(int x,int y)
	{
		a=x;
	b=y;
	}
	public void display()
	{
		System.out.println("a = "+a);
		System.out.println("b="+b);
	}
}
class A3
{
public static void main(String args[]) 
{
A1 obj=new A1(8,2);
obj.display();
}
}