class A
{
	int n,rev,m,r;
	public void cal()
	{
		rev=0;
		m=n;	
		while(n>0)
		{
			r=n%10;
			rev=rev*10+r;
			n=(int)(n/10);
		}
		if(m==rev)
		System.out.println(" no is pali");
		else
		System.out.println("no is not pali");
	}
}
class pali1
{
	public static void main(String args[])
	{
		A obj=new A();
		obj.n=122;
		obj.cal();
	}
}