import java.io.*;
class A
{
	int n,rev,r;
	public A() throws IOException
	{
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the no=");
		n=Integer.parseInt(in.readLine());
		rev=0;
		while(n>0)
		{
				r=n%10;
				rev=rev*10+r;
				n=(int)(n/10);
		}
	
	}
		public void output()
		{
			
			System.out.println("reverse no is="+rev);
		}
}
class amit
{
		public static void main(String args[]) throws IOException
		{
				BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
				A obj=new A();
				obj.output();
				
				
		}
}