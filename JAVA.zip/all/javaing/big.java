import java.io.*;
class big
{
	public static void main(String args[]) throws IOException
	{
		int n,r,big=0;
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the no=");
		n=Integer.parseInt(in.readLine());
		while(n>0)
		{
			r=n%10;
			if(r>big)
			{
				big=r;	
			}
			n=(int)(n/10);
		}
		System.out.println("biggest digit in a number"+big);
	}
}
