import java.io.*;
class A
{
	int n,rev,m,r;
	

	public void input() throws IOException
	{
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the no=");
		n=Integer.parseInt(in.readLine());
		
	}
	public void output()
	{
		m=n;
		while(n>0)
		{
			r=n%10;
			rev=rev*10+r;
			n=(int)(n/10);
		}
		if(m==rev)
		System.out.println("no. is palidrome");
		else
		System.out.println("no. is not palidrome");
	}
}
class pali2
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		A obj=new A();
		obj.input();
		obj.output();
	}
} 
		