import java.io.*;
class arms
{
	public static void main(String args[]) throws IOException
	{
		int n,m,r,arm=0;
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the no");
		n=Integer.parseInt(in.readLine());
		m=n;	
		while(n>0)
		{
			r=n%10;
			arm=arm+(r*r*r);
			n=(int)(n/10);
		}
		if(m==arm)
		System.out.println("no is armstrong");
		else
		System.out.println("no is not armstrong");
	}
}

