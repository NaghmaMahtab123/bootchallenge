import java.io.*;
abstract class bank
{
int accno;
double bal;
	public void input(int a,double b)
	{
		accno=a;
		bal=b;
	}	
	abstract void dep(int x);
	abstract void with(int y);
	
}
class op extends bank
{
	void dep(int x)
	{
	
	bal=bal+x;
	System.out.println("CURRENT AMOUNT = "+bal);
	}
		

void with(int y)
{
bal=bal-y;
System.out.println("CURRENT AMOUNT = "+bal);
}

void detail()
{
	System.out.println("ACCOUNT NO = "+accno);
	System.out.println("CURRENT AMOUNT = "+bal);
}
}

class operate
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		op obj=new op();
		obj.input(2153,5000);
		System.out.println("ENTER YOUR CHOICE ");
		System.out.println("1. DEPOSIT");
		System.out.println("2. WITHDRAW");
		System.out.println("3.SHOW USER DETAILS");
		int ch=Integer.parseInt(in.readLine());
		switch(ch)
		{
		case 1: 	System.out.println("ENTER YOUR DEPOSIT AMOUNT");
					int x=Integer.parseInt(in.readLine());
					obj.dep(x);
					break;
		
		case 2: 	System.out.println("ENTER YOUR WITHDRAW AMOUNT");
					int y=Integer.parseInt(in.readLine());
					obj.with(y);
					break;
		case 3:
					obj.detail();
					break;
					
		default: 	System.out.println("WRONG CHOICE");
	}
	
}
}	

	