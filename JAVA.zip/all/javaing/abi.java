import java.io.*;
abstract class data
{
		abstract void display();
}
class abi extends data
{
	void display()
	{
		System.out.println("concept of abstract class");
	}

public static void main(String args[])
{
	abi obj=new abi();
	obj.display();
}
}