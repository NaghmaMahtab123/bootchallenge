import java.io.*;
class A1
{
	int a,b,s;
	public void input() throws IOException
	{
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the two no=");
		a=Integer.parseInt(in.readLine());
		b=Integer.parseInt(in.readLine());
		s=a+b;
	}
	public void display()
	{
		System.out.println("sum"+s);
	}

public static void main(String args[]) throws IOException
{
BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
A1 obj=new A1();
obj.input();
obj.display();
}
}