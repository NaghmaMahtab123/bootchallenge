import java.io.*;
class A
{
	int a;
	A()
	{
		a=50;
	}
	void disp()
	{
		System.out.println("we are in class A "+a);
		
	}
}
class B extends A
{
	int b;
	B()
	{
		b=80;
	}
	void display()
	{
			super;
			System.out.println("we are in class B "+b);
	}
	
}
class maidata
{
	public static void main(String args[])
	{
		B obj=new B();
		obj.display();
	}
}
