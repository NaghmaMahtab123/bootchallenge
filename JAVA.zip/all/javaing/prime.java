import java.util.*;
class prime
{
	public static void main(String args[])
	{
		int n,l=0,i;
		Scanner in =new Scanner(System.in);
		System.out.println("entre the no=");

		n=in.nextInt();
		for(i=1;i<=n;i++)
		{
			if(n%i==0)
			{
				l=l+1;
			}
		}
		if(l==2)
		System.out.println("no is prime");
		else
		System.out.println("no is not prime");
	}
}
		