import java.io.*;
class A1
{
	int a;
	A1(int x)
	{
		a=x;
	}
	public void display()
	{
		System.out.println("a = "+a);
	}
}
class A2
{
public static void main(String args[]) 
{
A1 obj=new A1(8);
obj.display();
}
}