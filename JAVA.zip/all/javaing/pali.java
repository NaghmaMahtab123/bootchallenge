import java.io.*;
class pali
{
	public static void main(String args[]) throws IOException
	{
		int n,m=0,rev=0,r;
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the number");
		n=Integer.parseInt(in.readLine());
		m=n;
		while(n>0)
		{
			r=n%10;
			rev=rev*10+r;
			n=(int)(n/10);
		}
		if(m==rev)
		System.out.println("no. is pali");
		else
		System.out.println("no. is not pali");
	}
}