class error
{
	public static void main(String args[])
	{
		int a[]={5,10};
		int b=5;
		try
		{
			int x=a[2]/b-a[1];
		}
		catch(ArithmeticException e)
		{
			System.out.println("DIVISON BY ZERO");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("ARRAY INDEX ERROR");
		}
		
		catch(ArrayStoreException e)
		{
			System.out.println("WRONG DATA TYPE");
		}
		finally
		{
		int y=a[1]/a[0];
		System.out.println("WELCOME");
		System.out.println("Y = "+y);
		}
	
	}
}