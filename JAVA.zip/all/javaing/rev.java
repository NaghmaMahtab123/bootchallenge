import java.io.*;
class A
{
	int re,r,n;
	public void input() throws IOException
	{
		
		BufferedReader in =new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the no=");
		n=Integer.parseInt(in.readLine());
		
		while(n>0)
		{
			r=n%10;
			re=re*10+r;
			n=(int)(n/10);
		}
		System.out.println("reverse no is="+re);
	}
	
	
		
		
	
}
class rev
{
	public static void main(String args[]) throws IOException
	{
			BufferedReader in =new BufferedReader(new InputStreamReader(System.in));
			A obj=new A();
			obj.input();
			
		
	}
}