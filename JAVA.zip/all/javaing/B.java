class A
{
	int a,b;
	public void cal()
	{
		int s=a+b;
		System.out.println("sum of two nos=",s);
	}
	
}
class add
{
	public Static void main(String args[])
	{
		A obj=new A();
		obj.a=5,b=9;
		obj.cal();
	}
}