class A extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			if(i==1) 
			{
			yield();
			}
			System.out.println("FROM THREAD A : I = "+i);
		}
		System.out.println("EXIT FROM A");
	
	}
}

class B extends Thread
{
	public void run()
	{
		for(int j=1;j<=5;j++)
		{
			System.out.println("FROM THREAD B : J = "+j);
			if(j==3) 
			stop();
		}
		System.out.println("EXIT FROM B");
	
	}
}

class C extends Thread
{
	public void run()
	{
		for(int k=1;k<=5;k++)
		{
		  System.out.println("FROM THREAD C : K = "+k);
		  if(k==1)
			  try
			  {
				  sleep(1000);
		}
		catch(Exception e)
		{
			
		}
		}
		System.out.println("EXIT FROM C");
	}
}

class work
{
	public static void main(String args[])
	{
		A obj=new A();
		B obj1=new B();
		C obj2=new C();
		
		System.out.println("START THREAD A");
		obj.start();
		
		System.out.println("START THREAD B");
		obj1.start();
		
		System.out.println("START THREAD C");
		obj2.start();
		
	}
}
