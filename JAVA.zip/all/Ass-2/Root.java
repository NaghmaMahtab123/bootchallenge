class Root
{
	public static void main(String args[])
	{
		double a,b,c,r1,r2;
		a=4; b=6; c=1;
		r1= (-1)*b + Math.sqrt(b*b -4*a*c)/2*a;
		r2= (-1)*b - Math.sqrt(b*b -4*a*c)/2*a;
		System.out.println("Root1 = "+ r1);
		System.out.println("Root2 = "+ r2);
	}
}