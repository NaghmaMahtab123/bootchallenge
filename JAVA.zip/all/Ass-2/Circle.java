class Circle
{
	public static void main(String args[])
	{
		double rad=4.5, area=0.0;
		area=3.14*rad*rad;
		System.out.println("Area of the triangle is: "+area);
	}
}