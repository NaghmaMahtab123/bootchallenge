class SimpleInt
{
	public static void main(String args[])
	{
		double p,r,t,si;
		p=5000;
		r=4.5;
		t=4;
		si=(p*r*t)/100;
		System.out.println("Simple Interest: "+si);
	}
}