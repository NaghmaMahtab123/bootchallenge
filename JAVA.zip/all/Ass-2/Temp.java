//02-12-2013
//Program to convert temperature n celcius.
class Temp
{
	public static void main(String args[])
	{
		double f,c;
		f=212;
		c = (f-32)/1.8;
		System.out.println("Fahrenheit Temp: " + f);
		System.out.println("Celcius Temp: " + c);
	}
}