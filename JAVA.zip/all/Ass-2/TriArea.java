class TriArea
{
	public static void main(String args[])
	{
		double a,b,c,s,area;
		a=4.3;
		b=5.4;
		c=3.3;
		s= (a+b+c)/2;
		area=Math.sqrt(s * (s-a) * (s-b) * (s-c));
		System.out.println("Area of non-equilateral triangle: "+area);
	}
}