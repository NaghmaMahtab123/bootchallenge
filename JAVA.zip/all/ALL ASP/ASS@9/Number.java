interface prime
{
	int num=10;
	public void cal();
}
class Num implements prime
{
	int c=0;
	public void cal()
	{
		for(int i=1;i<num;i++)
		{	
			if(num%i==0)
			{
				c++;
			}
		}
			if(c==1)
			System.out.println("Prime");
			
			else
			 System.out.println("Not Prime");
		
	}
}
public class Number
{
	public static void main(String a[])
	{
		Num ob=new Num();
		ob.cal();
	}
}