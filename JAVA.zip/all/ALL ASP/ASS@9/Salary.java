import java.io.*;
interface emp
{
	String name="abc";
	int age=30;
	String gen="male";
	public void read();
	public void calculate();
	//void disp();
}
class Empsal implements emp
{
	float sal;
	public void disp()
	{
		System.out.println("Name="+name);
		System.out.println("Age="+age);
		System.out.println("Gender="+gen);
	}

	public void read()
	{
		int choice;
		DataInputStream sd=new DataInputStream(System.in);
		try
		{
			System.out.println("1.Manager");
			System.out.println("2.Salesman");
			System.out.println("3.Cleark");
			System.out.println("Enter your choice:");
			choice=Integer.parseInt(sd.readLine());
		
		switch(choice)
		{
			case 1:
					sal=15000;
					break;
			case 2:
					sal=10000;
					break;
			case 3:
					sal=8000;
					break;
			default:
					System.out.println("Wrong Entry..!!");
		}
		}
		catch(Exception e)
		{}
		
	}
		public void calculate()
		{
			float hra,da,pf,ns,gs;
			hra=sal*15/100;
			da=sal*10/100;
			pf=sal*5/100;
			gs=sal+da+hra;
			ns=gs-pf;
			System.out.println("Gross sal="+gs);
			System.out.println("Net sal="+ns);
		}
}
public class Salary
{
	public static void main(String arg[])
	{
		Empsal ob=new Empsal();
		ob.read();
		ob.disp();
		ob.calculate();
	}
}