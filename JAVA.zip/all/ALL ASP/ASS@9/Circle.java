interface data
{
	float r=2;
	public void area();
}
class CircleDemo implements data
{
	float ar;
	public void area()
	{
		ar=3.14f*r*r;
		System.out.println("Area of circle="+ar);
	}
}
public class Area
{
	public static void main	(String arg[])
	{
		CircleDemo ob=new CircleDemo();
		ob.area();
	}
}