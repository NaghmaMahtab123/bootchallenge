public class StringTest 
{
public static void demoException() 
{

try 
{
String strTemp = "RAM";
strTemp.charAt(3);

} 
catch (StringIndexOutOfBoundsException e) 
{
System.out.println("Error : string index out of bounds exception");
//e.printStackTrace();
}
}
public static void main(String[] args) 
{
demoException();
}
}