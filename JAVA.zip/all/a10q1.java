import pack.Addition;
class Main
{
  public static void main(String args[])
  {
    Addition obj=new Addition();
    int val=obj.add(9,9);
    System.out.println("Addition of two nos. is"+val);
  }
}