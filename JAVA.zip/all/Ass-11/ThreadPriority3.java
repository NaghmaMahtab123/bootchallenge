import java.io.*;
import java.lang.*;
class A extends Thread
{
  public void run()
  {
    System.out.println("Thread A Started ");
    for(int i=1;i<=5;i++)
    {
      System.out.println("Thread A : "+i);
    }  
  }
}
class B extends Thread
{
  public void run()
  {
    System.out.println("Thread B Started ");
    for(int j=1;j<=5;j++)
    {
      System.out.println("Thread B : "+j);
    }  
  }
}
class C extends Thread
{
  public void run()
  {
    System.out.println("Thread C Started ");
    for(int k=1;k<=5;k++)
    {
      System.out.println("Thread C : "+k);
    }  
  }
}
class ThreadPriority3
{
  public static void main(String arg[])
  {
    A ob1=new A();
    B ob2=new B();
    C ob3=new C();
    ob1.setPriority(Thread.NORM_PRIORITY);
    ob2.setPriority(Thread.MIN_PRIORITY);
    ob1.setPriority(Thread.MAX_PRIORITY);
    ob1.start();
    ob2.start();
    ob3.start();
  }
}