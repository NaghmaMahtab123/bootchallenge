import java.io.*;
import java.lang.*;
class MainThread4
{
  public static void main(String ar[])
  {
    Thread t=Thread.currentThread();
    System.out.println("Current Thread : "+t);
    System.out.println(" Name : "+t.getName());
    System.out.println(" ");
    t.setName(" New Thread ");
    System.out.println(" After changing name ");
    System.out.println("Current Thread : "+t);
    System.out.println("Name : "+t.getName());
    System.out.println(" ");
    System.out.println(" This thread prints first 10 numbers only ");
    try
    {
      for(int i=1;i<=10;i++)
      {
        System.out.println(i);
        System.out.println(" ");
        Thread.sleep(1000);
      }
    }
    catch(Exception ex)
    { }
  }     
}