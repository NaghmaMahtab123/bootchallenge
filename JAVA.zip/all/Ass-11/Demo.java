import java.io.*;
import java.lang.*;
class UserThread implements Runnable
{
 Thread t;
 UserThread()
  {
    t=new Thread(this,"UserThread");
    System.out.println("thread name:" +t);
    t.start();
  }
 public void run()
 {
   try
    {
      for(i=0;i<5;i++)
      {
        System.out.println("i:" +i);
        t.sleep(1000);
      }
    }
   catch(InterruptedException ie)
    {
      ie.printStackTrace();
    }
  }
}
class Demo
{
 public static void main(String arg[])
  {
    UserThread ut=new UserThread();
  }
}