import java.io.*;
class Shape
{
	void area()
	{
		System.out.println("Deriving from shape...");
	}
}
class Square extends Shape
{
	int s;
	Square(int s1)
	{
		s = s1;
	}
	void area()
	{
		System.out.println("Area of the square is: " + s*s);
	}
}
class Rectangle extends Shape
{
	int h, w;
	Rectangle(int h1, int w1)
	{
		h = h1;
		w = w1;
	}
	void area()
	{
		System.out.println("Area of the rectangle is: " + h*w);
	}
}
class ShapeDemo
{
	public static void main(String args[])
	{
		Shape obj = new Shape();
		Square sqr = new Square(4);
		Rectangle rect = new Rectangle(3,5);
		Shape ref;
		ref = obj;
		ref.area();
		ref = sqr;
		ref.area();
		ref = rect;
		ref.area();
	}
}