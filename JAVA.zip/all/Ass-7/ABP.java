import java.io.*;
class Author
{
	String aName, qual;
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);
	void a_input() throws IOException
	{
		System.out.println("Enter author name:  ");
		aName = br.readLine();
		System.out.println("Enter qualification: ");
		qual = br.readLine();
	}
	void a_output()
	{
		System.out.println("Author Name: "+aName);
		System.out.println("Qualification: "+qual);
	}
}
class Book extends Author
{
	String bName, subject;
	void b_input() throws IOException
	{
		System.out.println("Enter Book name: ");
		bName = br.readLine();
		System.out.println("Enter subject: ");
		subject = br.readLine();
	}
	void b_output()
	{
		System.out.println("Book name: "+bName);
		System.out.println("Subject: "+subject);
	}
}
class Publisher extends Book
{
	String pName, pAdd;
	void p_input() throws IOException
	{
		System.out.println("Enter publisher name: ");
		pName= br.readLine();
		System.out.println("Enter publisher Address: ");
		pAdd = br.readLine();
	}
	void p_output()
	{
		System.out.println("Publisher name: "+pName);
		System.out.println("Publisher Address: "+pAdd);
	}
}
class ABP
{
	public static void main(String args[]) throws IOException
	{
		Publisher p = new Publisher();
		p.a_input();
		p.b_input();
		p.p_input();
		System.out.println("Here is the output.");
		p.a_output();
		p.b_output();
		p.p_output();
	}
}