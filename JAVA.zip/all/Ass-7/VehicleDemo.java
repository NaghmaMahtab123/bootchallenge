import java.io.*;
class Vehicle
{
	String vName, vNo;
	String mfr;
	float weight,price;
	int now, nog;
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader (in);
	void v_input() throws IOException
	{
		System.out.println("Enter vehicle name: ");
		vName = br.readLine();
		System.out.println("Enter vehicle number: ");
		vNo = br.readLine();
		System.out.println("Enter manufacturer: ");
		mfr = br.readLine();
		System.out.println("Enter weight of the vehicle: ");
		weight = Float.parseFloat(br.readLine());
		System.out.println("Enter price of the vehicle: ");
		price = Float.parseFloat(br.readLine());
		System.out.println("Enter no of wheels: ");
		now =Integer.parseInt(br.readLine());
		System.out.println("Enter no of gears: ");
		nog = Integer.parseInt(br.readLine());
	}
	void v_output()
	{
		System.out.println("Vehicle name: "+vName);
		System.out.println("Manufacturer: "+mfr);
		System.out.println("Vehicle Number: "+vNo);
		System.out.println("Weight: "+weight);
		System.out.println("Price: "+price);
		System.out.println("No. of wheels: "+now);
		System.out.println("No. of gears: "+nog);
	}
}
class HeavyVehicle extends Vehicle
{
	void HVinput() throws IOException
	{
		super.v_input();
	}	
}
class LightVehicle extends Vehicle
{
	void LVinput() throws IOException
	{
		super.v_input();
	}
}
class TwoWheeler extends LightVehicle
{
	void read() throws IOException
	{
		super.LVinput();
	}
	void show()
	{
		super.v_output();
	}
}
class FourWheeler extends HeavyVehicle
{
	void get() throws IOException
	{
		super.HVinput();
	}
	void put()
	{
		super.v_output();
	}
}
class VehicleDemo
{	
	public static void main(String args[]) throws IOException
	{
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader (in);
		int choice;
		TwoWheeler TW = new TwoWheeler();
		FourWheeler FW = new FourWheeler();
		do
		{
			System.out.println("1. Two wheeler");
			System.out.println("2.Four wheeler");
			System.out.println("3.Exit");
			choice = Integer.parseInt(br.readLine());
			switch(choice)
			{
				case 1:
				TW.read();
				TW.show();
				break;
				case 2:
				FW.get();
				FW.put();
				break;
				case 3:
				System.exit(0);
			}
		}while (choice!=3);
	}
}