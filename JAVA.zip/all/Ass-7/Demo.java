import java.io.*;
class Person
{
	int age;
	String Name, Address;
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);
	void read() throws IOException
	{
		System.out.println("Enter Name: ");
		Name = br.readLine();
		System.out.println("Enter age: ");
		age = Integer.parseInt(br.readLine());
	}
	void show()
	{
		System.out.println("Name: "+Name);
		System.out.println("Age: "+age);
	}
}
class Student extends Person
{
	int roll;
	String std;
	void input() throws IOException
	{
		System.out.println("Enter roll number: ");
		roll = Integer.parseInt(br.readLine());
		System.out.println("Enter standard: ");
		std = br.readLine();
	}
	void output()
	{
		System.out.println("Roll: "+roll);
		System.out.println("Std: "+std);
	}
}
class Demo
{
	public static void main(String args[]) throws IOException
	{
		Student s = new Student();
		s.read();
		s.input();
		s.show();
		s.output();
	}
}