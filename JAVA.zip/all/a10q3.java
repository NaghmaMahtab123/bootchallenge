import test.Display;
import java.util.*;
class Main
{
  public static void main(String args[])
  {
  	Scanner sc=new Scanner(System.in);
  	Display obj=new Display();      
        System.out.println("Enter your name");
        String val=sc.next();
        obj.disp(val);
   }
}
   