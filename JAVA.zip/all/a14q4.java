import java.awt.*;
import java.applet.*;
public class a14q4 extends Applet {
	String s;
public void paint(Graphics g)
{
	
	g.drawString("Hello",10,50);
	setBackground(Color.yellow);
	setForeground(Color.red);
}

}
