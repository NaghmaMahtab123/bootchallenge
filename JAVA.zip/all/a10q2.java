import special.Special;
import java.util.*;
class Specialor
{
 public static void main(String args[])
 {
  int n;
  Scanner sc=new Scanner(System.in);
  Special obj=new Special();
  System.out.println("Enter a number to check for special number");
  n=sc.nextInt();
  obj.check(n);
 }
}
  