import java.awt.*;
import java.applet.*;
public class a14q1 extends Applet {
	public void paint(Graphics g)
	{
		g.drawString("welcome to my page",10,10);
	}

}
