import java.awt.*;
import java.applet.*;
/*
<applet code="Hello1.class" width="200" height="200">
</applet>
*/
public class Hello1 extends Applet
{
	public void paint(Graphics g)
	{
		g.drawString("Hello",20,50);
                g.drawstring("Welcome",30,80);
	}
}