import java.awt.*;
import java.applet.*;
/*
<applet code="HelloBG.class" width="200" height="200">
</applet>
*/
public class HelloBG extends Applet
{
	public void paint(Graphics g)
	{
		setBackground(Color.yellow);
		g.drawString("Hello! Appelet",20,50);
	}
}