import java.applet.*;
import java.awt.*;
/* <applet code="ParamDemo.class" width="400" height="400">
<param name="msg" value="Hello! This is demo program for parameter in applet">
</applet>
*/
public class ParamDemo extends Applet
{
	String str;
	public void init()
	{
		str=getParameter("msg");
	}
	public void paint(Graphics g)
	{
		g.drawString(str, 80,200);
	}
}