import java.applet.*;
import java.awt.*;
/*<applet code="Face.class" width=400 height=400>
</applet>
*/
public class Face extends Applet
{
	public void paint(Graphics g)
	{
		//draw smiley
		g.setColor(Color.yellow);
		g.fillOval(20,20,100,100);
		g.setColor(Color.black);
		g.fillOval(50,50,10,10);
		g.fillOval(80,50,10,10);
		g.fillArc(55,70,30,30,180,180);
		g.setColor(Color.yellow);
		g.fillArc(57,70,25,26,180,180);
		//draw Sanjay Ka B'Day Gift
		g.setColor(Color.yellow);
		g.fillOval(120,120,100,100);
		g.setColor(Color.black);
		g.drawArc(150,150,10,10,180,-180);
		g.drawArc(180,150,10,10,180,-180);
		g.setColor(Color.red);
		g.fillArc(155,170,30,30,180,180);
		g.setColor(Color.yellow);
		g.fillArc(167,175,15,15,180,60);
		g.fillArc(155,175,15,15,180,45);
		g.fillArc(180,175,15,15,180,45);
		
	}
}