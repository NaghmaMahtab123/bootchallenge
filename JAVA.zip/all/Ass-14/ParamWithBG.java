import java.applet.*;
import java.awt.*;
/* <applet code="ParamWithBG.class" width="400" height="400">
<param name="msg" value="Hello! This is demo program for parameter in applet">
</applet>
*/
public class ParamWithBG extends Applet
{
	String str,bgclr,fgclr;
	public void init()
	{
		str=getParameter("msg");
	}
	public void paint(Graphics g)
	{
		setBackground(Color.blue);
		setForeground(Color.white);
		g.drawString(str, 80,200);
	}
}