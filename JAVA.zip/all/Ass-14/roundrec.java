import java.awt.*;
import java.applet.*;
/*<applet code="roundrec.class" height=300 width=400>
</applet>*/
public class roundrec extends Applet
{
  public void paint(Graphics g)
   {
     g.fillRoundRect(50,50,100,50,30,40);
   }
}
