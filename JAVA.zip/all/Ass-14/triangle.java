import java.awt.*;
import java.applet.*;
/*<applet code="triangle.class" height=300 width=300>
</applet>*/
public class triangle extends Applet
{
  public void paint(Graphics g)
  {
    g.drawLine(150,20,70,150);
    g.drawLine(150,20,230,150);
    g.drawLine(70,150,230,150);
  }
}
