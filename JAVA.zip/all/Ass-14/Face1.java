import java.awt.*;
import java.applet.*;
/*<applet code="Face1.class" height="300" width="300">
</applet>
*/
public class Face1 extends Applet
{
	public void paint(Graphics g)
	{
		g.setColor(Color.yellow);
		g.fillOval(20,20,100,100);
		g.setColor(Color.black);
		g.fillOval(50,50,10,10);
		g.fillOval(80,50,10,10);
		g.fillArc(60,80,20,20,225,135);
	}
}