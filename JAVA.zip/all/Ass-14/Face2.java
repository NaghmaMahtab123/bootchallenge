import java.awt.*;
import java.applet.*;
/*<applet code="Face2.class" height="300" width="400">
</applet>*/
public class Face2 extends Applet
{
  public void paint(Graphics g)
   {
     g.setColor(Color.yellow);
     g.fillOval(50,50,150,150);
     g.setColor(Color.black);
     g.fillOval(90,90,20,20);
     g.fillOval(130,90,20,20);
     g.setColor(Color.black);
     g.drawLine(120,130,125,140);
     g.drawLine(130,130,125,140);
     g.setColor(Color.black);
     g.fillArc(90,120,50,50,180,180);
     g.setColor(Color.yellow);
     g.fillArc(95,120,40,45,180,180);
     g.setColor(Color.blue);
     g.fillArc(115,135,60,60,180,180);
     g.setColor(Color.white);
   }
}