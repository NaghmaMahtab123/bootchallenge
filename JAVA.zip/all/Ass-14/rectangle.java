import java.awt.*;
import java.applet.*;
/*<applet code="rectangle.class" height=300 width=300>
</applet>*/
public class rectangle extends Applet
{
  public void paint(Graphics g)
   { 
     g.setColor(Color.red);
     g.fillRect(50,50,100,100);
   }
}