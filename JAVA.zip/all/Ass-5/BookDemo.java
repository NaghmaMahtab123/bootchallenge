class Book
{
	String bname, aname;
	int nop, edition;
	Book()
	{
		bname = "Java- Complete Reference";
		aname = "Herzd";
		nop = 800;
		edition = 2009;
	}
	void show()
	{
		System.out.println("Book name: " + bname);
		System.out.println("Author name: " + aname);
		System.out.println("No of pages: " + nop);
		System.out.println("Edition: " + edition);
	}
}
class BookDemo
{
	public static void main(String args[]) 
	{
		Book b = new Book();
		b.show();
	}
}