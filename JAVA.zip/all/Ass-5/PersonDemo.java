import java.io.*;
class Person
{
	int age;
	String name;
	void input() throws IOException
	{
		System.out.println("Enter name and age of person : ");
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		name = br.readLine();
		age = Integer.parseInt(br.readLine());
	}
	void output()
	{
		System.out.println("Name = " + name);
		System.out.println("Age = " + age);
	}
}
class PersonDemo
{
	public static void main(String args[]) throws IOException
	{
		Person raju = new Person();
		raju.input();
		raju.output();
	}
}