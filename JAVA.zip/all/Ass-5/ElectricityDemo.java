class Electricity
{
	int sr, er;
	Electricity(int s, int e)
	{
		sr = s;
		er = e;
	}
	void cal_bill()
	{
		int unit, total;
		unit = er- sr;
		total = unit *5;
		System.out.println("Unit consumed: " + unit);
		System.out.println("Total Bill: " + total);
	}
}
class ElectricityDemo
{
	public static void main(String args[])
	{	
		Electricity e = new Electricity(225,335);
		e.cal_bill();
	}
}