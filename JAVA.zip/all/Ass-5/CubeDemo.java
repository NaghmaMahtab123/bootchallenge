class Cube
{
	float side;
	Cube(float s)
	{
		side = s;
	}
	void cal_volume()
	{
		float volume;
		volume = (float)Math.pow(side,3);
		System.out.println("Volume of the cube : " + volume);
	}
}
class CubeDemo
{
	public static void main(String args[])
	{
		Cube c = new Cube(5.3f);
		c.cal_volume();
	}
}