class Hello
{
	void sayHello()
	{
		System.out.println("Hello!!!");	
	}
}
class HashCode
{
	public static void main(String args[])
	{
		Hello h = new Hello();
		h.sayHello();
		System.out.println("The object code (hash code) of the object h is: " +h.hashCode());
	}
}