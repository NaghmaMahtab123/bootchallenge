interface Prime1
{
	final int var1=10;
	final int var2=20;
	void calPrime();
}
class Prime implements Prime1
{
	public void calPrime()
	{
		int i,x,num,sig=0;
		for(i=var1;i<=var2;i++)
		{
			num=i;
			sig=0;
			for(x=1;x<=num;x++)
			{
				if(num%x==0)
					sig+=1;
			}
			if (sig==2)
				System.out.println("Prime Number: " +num);
		}
	}
}
class PrimeDemo
{
	public static void main(String args[])
	{
		Prime obj = new Prime();
		obj.calPrime();
	}
}