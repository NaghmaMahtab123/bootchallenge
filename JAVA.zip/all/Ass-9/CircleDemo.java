import java.io.*;
interface area
{
	final float pie=3.14f;
	float cal(float r);
}
class CirArea implements area
{
	public float cal(float r)
	{
		return pie * r * r;
	}
}
class CircleDemo
{
	public static void main( String args[]) throws IOException
	{
		float rad, area;
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter radius: ");
		rad = Float.parseFloat(br.readLine());
		CirArea ca = new CirArea();
		area = ca.cal(rad);
		System.out.println("Area: " +area);
	}
}