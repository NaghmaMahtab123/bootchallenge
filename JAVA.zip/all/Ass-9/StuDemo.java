import java.io.*;
interface student
{
	void s_input() throws IOException;
}
interface fee
{
	void f_input() throws IOException;
}
class student_fee implements student, fee
{
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);
	String name;
	int age,roll;
	float fee;
	public void s_input() throws IOException
	{
		System.out.println("Enter name and age of student: ");
		name = br.readLine();
		age = Integer.parseInt(br.readLine());
	}
	public void f_input() throws IOException
	{
		System.out.println("Enter roll number and fee: ");
		roll = Integer.parseInt(br.readLine());
		fee = Float.parseFloat(br.readLine());
	}
	void show()
	{
		System.out.println("Roll : " +roll);
		System.out.println("Name : " +name);
		System.out.println("Age : " +age);
		System.out.println("Fee : " +fee);
	}
}
class StuDemo
{
	public static void main(String args[]) throws IOException
	{
		student_fee sf = new student_fee();
		sf.s_input();
		sf.f_input();
		sf.show();
	}
}