
import java.sql.*;
interface Data
{
	public void Disp();
}
public class Db {
			int x;
			String y;
			public void Disp()
			{
				System.out.println("Roll No:"+x);
				System.out.println("Name:"+y);
				
			}
	public static void main(String args[])
	{	
		try
		{
			Db obj=new Db();
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			String dburl="jdbc:odbc:DSNMSACCESS";
			Connection conn=DriverManager.getConnection(dburl);
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from stu");
			while(rs.next())
			{
				obj.x=rs.getInt("Rollno");
				obj.y=rs.getString("Name");
				obj.Disp();
			}
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		