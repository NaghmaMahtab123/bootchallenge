class DMD
{
	void show()
	{
		System.out.println("This is the super class");
	}
}
class DMD1 extends DMD
{
	int a,b;
	DMD1(int x, int y)
	{
		a=x;
		b=y;
	}
	void show()
	{
		System.out.println("Sum of " + a + " & " + b + " is : " +(a+b));
	}
}
class DMD2 extends DMD
{
	String msg;
	DMD2(String m)
	{
		msg = m;
	}
	void show()
	{
		System.out.println(msg);
	}
}
class DMDDemo
{
	public static void main(String args[])
	{
		DMD obj = new DMD();
		DMD1 o1 = new DMD1(4,6);
		DMD2 o2 = new DMD2("This is the demonstartion of Dynamic Method Dispatch.");
		DMD ref;
		ref= obj;
		ref.show();
		ref = o1;
		ref.show();
		ref = o2;
		ref.show();
	}
}
	