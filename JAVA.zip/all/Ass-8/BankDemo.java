import java.io.*;
abstract class Bank
{
	int acNo;
	String acHoldName;
	float balance;
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);
	Bank(String nm, int ano, float bal)
	{
		acHoldName = nm;
		acNo = ano;
		balance = bal;
	}
	void deposit() throws IOException
	{
		float amt;
		System.out.println("Enter amount to be deposited: ");
		amt = Float.parseFloat(br.readLine());
		balance +=amt;
		System.out.println("Rs /- " + amt +" has been successfully deposited.");
		System.out.println("Your current balance is Rs/- " + balance);
	}
	abstract void withdraw();
}
class absClass extends Bank
{
	absClass(String nm, int ano, float bal)
	{
		super(nm, ano,bal);
	}
	void withdraw()
	{
		float amt;
		try
		{
		System.out.println("Enter amount to be withdrawn: ");
		amt = Float.parseFloat(br.readLine());
		if (amt > balance)
			System.out.println("Insufficient balance. Transaction could not be completed.");
		else
		{	
			balance -=amt;
			System.out.println("Rs /- " +amt + " has been successfully withdrawn.");		
			System.out.println("Your current balance is Rs/- " + balance);
		}
		}
		catch(IOException e){}
	}
}
class BankDemo
{
	public static void main(String args[]) throws IOException
	{
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		absClass obj = new absClass("Sagar", 123321, 1000000.0f);
		obj.deposit();
		obj.withdraw();
	}
}