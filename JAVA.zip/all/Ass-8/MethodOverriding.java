class A
{
	int a, b;
	A(int a1, int b1)
	{
		a=a1;
		b=b1;
	}
	void sum()
	{
		System.out.println("Sum = " + (a+b));
	}
}
class B extends A
{
	float x, y;
	B(int a1, int b1, float x1, float y1)
	{
		super(a1,b1);
		x = x1;
		y = y1;
	}
	void sum()
	{
		super.sum();
		System.out.println("Sum = " + (x+y));
	}
}
class MethodOverriding
{
	public static void main(String args[])
	{
		B obj = new B(4,6,4.5f,5.5f);
		obj.sum();
	}
}