class MO
{
	int sum;
	float c, d;
	void cal(int a, int b)
	{
		sum = a+b;
		System.out.println("Sum of two integers is: " +sum);
	}
	float cal(float m, float n)
	{
		c= m;
		d = n;
		return (c+d);
	}
}
class MODemo
{
	public static void main(String args[])
	{
		float val;
		MO obj = new MO();
		obj.cal(2,5);
		val = obj.cal(4.5f,3.4f);
		System.out.println("Sum of two floats : "+val);
	}
}