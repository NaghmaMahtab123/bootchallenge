import java.io.*;
class Cloth
{
	float cost, len, rate;
	InputStreamReader in = new InputStreamReader(System.in);
	BufferedReader br = new BufferedReader(in);
	void input() throws IOException
	{
		System.out.println("Enter the length and rate of the cloth: ");
		len = Float.parseFloat(br.readLine());
		rate = Float.parseFloat(br.readLine());
	}
	void discount() throws IOException
	{
		float dis;
		cost = rate* len;
		dis = cost*.40f + cost*.30f;
		System.out.println("Discount = " + dis);
		System.out.println("Amount Payable = " + (cost-dis));
	}
}
class Readymade extends Cloth
{
	void discount() throws IOException
	{
		float dis;
		cost = rate * len;
		dis = 0;
		System.out.println("Discount = " + dis);
		System.out.println("Amount Payable = " + (cost-dis));
	}
}
class ClothDemo
{
	public static void main(String args[]) throws IOException
	{
		Cloth c = new Cloth();
		Readymade r = new Readymade();
		Cloth ref;
		System.out.println("Discount of flat 40% + 30%");
		ref = c;
		ref.input();
		ref.discount();
		System.out.println("Offer expired... 0 Discount");
		ref = r;
		ref.input();
		ref.discount();
	}
}