//Program to add two numbers

class Sum
{
	public static void main(String args[])
	{
		int a=10 , b=5;
		System.out.println("Sum = "+ (a+b));
		System.out.println("Diff = " + (a-b));
		System.out.println("Product = " +(a*b) );
		System.out.println("Division = " + (a/b));
		System.out.println("Modulus = " + (a%b));
	}
}
