//Program to swap two numbers without using third variable

class DemoProg
{
	public static void main(String args[])
	{
		int a=4;
		float b=3;
		double d = 4.6758;
		char ch='S';
		String stg="anzarul";
		
		System.out.println("Integer = " + a);
		System.out.println("Float = " + b);
		System.out.println("Double = " +d);
		System.out.println("Char = " +ch);
		System.out.println("String = " +stg);
	}
}
