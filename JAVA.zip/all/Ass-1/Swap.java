//Program to swap two numbers

class Swap
{
	public static void main(String args[])
	{
		int a , b, temp;
		a=4;
		b=6;
		System.out.println("Numbers before swaping:");
		System.out.println("a= " +a);
		System.out.println("b= " +b);
		temp = a;
		a=b;
		b=temp;
		System.out.println("Numbers after swaping:");
		System.out.println("a= " +a);
		System.out.println("b= " +b);
	}
}
