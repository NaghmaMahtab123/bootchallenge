//25-11-2013
//Program to print your name

class Hello
{
	public static void main(String args[])
	{
		System.out.println("KARIM CITY COLLEGE");
	}
}