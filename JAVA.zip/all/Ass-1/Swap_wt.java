//Program to swap two numbers without using third variable
import java.io.*;
class Swap_wt
{
	public static void main(String args[])
	{
		int a , b, temp;
		a=4;
		b=6;
		System.out.println("Numbers before swaping:");
		System.out.println("a= " +a);
		System.out.println("b= " +b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("Numbers after swaping:");
		System.out.println("a= " +a);
		System.out.println("b= " +b);
	}
}
