package show;
import java.util.Date;
public class DandT
{
  public void disp()
  {
    Date date=new Date();
    System.out.println("Current date and time is:"+date.toString());
  }
}
	