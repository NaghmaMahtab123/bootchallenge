package test;
public class Display
{
  public void disp(String n)
  {
    System.out.println("Your name is:"+n);
  }
}
     	
   