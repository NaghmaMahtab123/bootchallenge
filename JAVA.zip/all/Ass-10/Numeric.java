import Number.*;
import java.io.*;
class Numeric
{
	public static void main(String args[]) throws IOException
	{
		int n, bool;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Special s = new Special();
		System.out.println("Enter any number:");
		n = Integer.parseInt(br.readLine());
		bool = s.chkSpecial(n);
		if (bool == 1)
			System.out.println("The number is special.");
		else
			System.out.println("The number is not special.");
	}
}