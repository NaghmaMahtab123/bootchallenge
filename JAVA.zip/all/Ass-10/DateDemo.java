import Number.*;
class DateDemo
{
	public static void main(String args[])
	{
		Today d =new Today();
		d.showDate();
		d.showTime();
	}
}