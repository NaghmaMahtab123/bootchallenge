package Number;
import java.util.*;
interface DateTime
{
	void showTime();
	void showDate();
}
public class Today implements DateTime
{
	Date d = new Date();
	public void showTime()
	{
		int hours, minutes, seconds;
		hours = d.getHours();
		minutes = d.getMinutes();
		seconds = d.getSeconds();
		if (hours >12)
			hours = hours -12;
		System.out.println("Current time is : " + hours + " : " + minutes + " : " + seconds);
	}
	public void showDate()
	{
		int dd, mm, yyyy;
		dd = d.getDate();
		mm = d.getMonth() + 1;
		yyyy = d.getYear();
		System.out.println("Current date is : " + dd + "/" + mm + "/" + yyyy);
	}
}