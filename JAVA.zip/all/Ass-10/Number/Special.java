package Number;
public class Special
{
	public int chkSpecial(int n)
	{
		int d, f=1, m, s=0;
		m = n;
		while(m!=0)
		{
			d = m%10;
			f = 1;
			for(int i = 1; i <= d; i++)
			{
				f = f * i;
			}
			s = s + f;
			m = m/10;
		}
		if (s == f)
			return 1;
		else
			return 0;		
	}
}