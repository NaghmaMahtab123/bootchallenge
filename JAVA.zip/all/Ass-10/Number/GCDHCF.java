package Number;
public class GCDHCF
{
	public int findGCD(int n)
	{
		int res=0;
		for(int i = 2;i <= n/2; i++)
		{
			if(n%i==0)
				res = i;
		}
		return res;
	}
}