package Number;
public class Num
{
	public float Add(float x, float y)
	{
		return (x+y);
	}
}