package Number.Prime;
public class PrimeDemo
{
	public int chkPrime(int n)
	{
		int c=0;
		for(int i=1; i<=n;i++)
		{
			if (n%i==0)
				c++;
		}
		if(c==2)
			return 1;
		else
			return 0;
	}
}