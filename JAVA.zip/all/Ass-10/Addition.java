import Number.*;
import java.io.*;
class Addition
{
	public static void main(String args[]) throws IOException
	{
		float a, b, res;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Num n = new Num();
		System.out.println("Enter two numbers : ");
		a = Float.parseFloat(br.readLine());
		b = Float.parseFloat(br.readLine());
		res = n.Add(a,b);
		System.out.println("Result: " + res);
	}
}