import Number.*;
import java.io.*;
class Numbers
{
	public static void main(String args[]) throws IOException
	{
		int num;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		GCDHCF gh=new GCDHCF();
		System.out.println("Enter any number: ");
		num = Integer.parseInt(br.readLine());
		System.out.println("GCD = "+gh.findGCD(num));
	}
}
	