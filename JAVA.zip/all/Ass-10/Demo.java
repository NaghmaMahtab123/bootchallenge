import Number.Prime.*;
import java.io.*;
class Demo
{
	public static void main(String args[]) throws IOException
	{
		int num, bool;
		BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
		PrimeDemo p = new PrimeDemo();
		System.out.println("Enter any number: ");
		num = Integer.parseInt(br.readLine());
		bool = p.chkPrime(num);
		if(bool ==1)
			System.out.println("Number is prime.");
		else
			System.out.println("Number is not prime.");
	}
}
