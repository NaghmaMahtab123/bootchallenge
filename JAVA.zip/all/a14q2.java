
import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
public class a14q2 extends Applet{
public void paint(Graphics g)
{
	g.drawString ("Hello World",15,50);
	setBackground(Color.yellow);
}
}
