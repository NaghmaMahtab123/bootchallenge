import java.io.*;
class CountThe
{
	public static void main(String args[]) throws IOException
	{
		String str, wrd="";
		char ch;
		int count=0;
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		System.out.println("Enter any string: ");
		str = br.readLine();
		str = str + " ";
		for(int i=0; i<str.length();i++)
		{
			ch = str.charAt(i);
			if(ch!= ' ')
				wrd = wrd+ch;
			else
			{
				if (wrd.equalsIgnoreCase("the"))
					count++;
				wrd="";
			}
		}
		System.out.println("No of \'the\' present in the string: " + count);
	}
}