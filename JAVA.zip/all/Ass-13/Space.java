import java.io.*;
class Space
{
	public static void main(String args[]) throws IOException
	{
		String str;
		int l=0, nos=0,noa=0,nod=0,other=0,c;
		char ch;
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		System.out.println("Enter any string: ");
		str = br.readLine();
		l = str.length();
		for(int i=0; i<l;i++)
		{
			ch=str.charAt(i);
			c=ch;
			if(ch==' ')
				nos++;
			else if((c>=65 && c <=90)|| (c>=97 && c <=122))
				noa++;
			else if(c>=48 && c<=57)
				nod++;
			else
				other++;
		}
		System.out.println("No of blank spaces : " +nos);
		System.out.println("No of alphabets : " + noa);
		System.out.println("No of digits : " + nod);
		System.out.println("No of special characters : "+other);
	}
}		