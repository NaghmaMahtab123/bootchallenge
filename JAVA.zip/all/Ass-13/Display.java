import java.io.*;
class Display
{
	public static void main(String args[]) throws IOException
	{
		String str;
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		System.out.println("Enter any string: ");
		str = br.readLine();
		System.out.println("Entered string is : " + str);
	}
}