import java.io.*;
class Rplc
{
	public static void main(String args[]) throws IOException
	{
		String str, s2="",f,r;
		char ch;
		int i;
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		System.out.println("Enter any string: ");
		str = br.readLine();
		System.out.println("Replace what: ");
		f=br.readLine();
		System.out.println("Replace with: ");
		r=br.readLine();
		String c="";
		for(i=0;i<str.length();i++)
		{
			ch=str.charAt(i);
                                                         c=c+ch;
			if(c.equals(f))
				s2=s2+r;
			else
				s2=s2+ch;
                                                   c="";
		}
		System.out.println("Replaced String : "+s2);
	}
}
