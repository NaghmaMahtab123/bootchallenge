import java.io.*;
class Len
{
	public static void main(String args[]) throws IOException
	{
		String str;
		int l=0;
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		System.out.println("Enter any string: ");
		str = br.readLine();
		l = str.length();
		System.out.println("Length of the string is : " +l);
	}
}
