import java.io.*;
class BigDigit
{
	int n;
	public void read() throws IOException
	{
		InputStreamReader in= new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		System.out.println("Enter any number: ");
		n=Integer.parseInt(br.readLine());
		Perform per = new Perform();
		per.check();
	}
	class Perform
	{
		public void check()
		{
			int d, max=0;
			while(n!=0)
			{
				d = n %10;
				if ( d > max)
					max = d;
				n = n /10;
			}
			System.out.println("Biggest digit : "+max);
		}
	}
	public static void main(String args[]) throws IOException
	{
		BigDigit bd = new BigDigit();
		bd.read();
	}
}
