import java.io.*;
class SumOfDigits
{
	int n;
	public void read() throws IOException
	{
		InputStreamReader in= new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		System.out.println("Enter any number: ");
		n=Integer.parseInt(br.readLine());
		Action act = new Action();
		act.check();
	}
	class Action
	{
		public void check()
		{
			int d,s=0,num;
			num = n;
			while(num!=0)
			{
				d = num %10;
				s = s + d;
				num = num /10;
			}
			System.out.println("Sum of digits : "+s);
		}
	}
	public static void main(String args[]) throws IOException
	{
		SumOfDigits sod = new SumOfDigits();
		sod.read();
	}
}
