import java.io.*;
import java.util.*;
class Automorphic
{
	static int n;
	static void read()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any number: ");
		n = sc.nextInt();
	}
	static void auto()
	{
		int m, s, d, c=0;
		s = n*n;
		m = n;
		while (n > 0)
		{
			c = c + 1;
			n = n /10;
		}
		d = (int)Math.pow(10,c);
		if ( m == s % d)
			System.out.println("Automorphic.");
		else
			System.out.println("Not automorphic.");
	}
	public static void main(String args[]) throws IOException
	{
		read();
		auto();
	}
}
