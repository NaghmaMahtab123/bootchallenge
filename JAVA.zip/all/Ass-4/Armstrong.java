class Armstrong
{
	public static void main(String args[])
	{
		int num, m, sum=0, d;
		num = Integer.parseInt(args[0]);
		m = num;
		while(num != 0 )
		{
			d = num % 10;
			sum = sum + (int)Math.pow(d,3);
			num = num /10;
		}
		if (sum == m)
			System.out.println("Armstrong.");
		else
			System.out.println("Not Armstrong.");
	}
}
