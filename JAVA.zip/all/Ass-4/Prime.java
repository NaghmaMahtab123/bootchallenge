import java.io.*;
class Prime
{
	static int n;
	static int c=0, i;
	static void check() throws IOException
	{
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		System.out.println("Enter value");
		n = Integer.parseInt(br.readLine());
		for(i=1;i<=n;i++)
		{
			if(n%i==0)
				c=c+1;
		}
		if (c==2)
			System.out.println("Prime.");
		else
			System.out.println("Not Prime.");
	}
	public static void main(String args[]) throws IOException
	{
		check();
	}
}	