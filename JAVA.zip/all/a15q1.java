

    import java.awt.*;
    import java.applet.*;
    import java.awt.event.*;
    //<applet code="circle.class" width=200 height=300></applet>
    public class a15q1 extends Applet
    {
    int x,y;
    public void init()
    {
    add a=new add();
    addMouseListener(a);
    }
    public void paint(Graphics g)
    {
    g.fillOval(x,y,30,30);
    }
    class add implements MouseListener
    {
    public void mouseClicked(MouseEvent e)
    {
    }
    public void mouseEntered(MouseEvent e)
    {
    x=e.getX();
    y=e.getY();
    repaint();
    }
    public void mouseReleased(MouseEvent e){}
    public void mousePressed(MouseEvent e){}
    public void mouseExited(MouseEvent e){
     
    }
    }
    }

