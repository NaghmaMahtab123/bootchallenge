import show.DandT;
class DispDate
{
	public static void main(String args[])
	{
		DandT obj=new DandT();
		obj.disp();
	}
}