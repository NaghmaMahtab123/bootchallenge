import java.io.*;
class Emp
{
	public static void main(String args[]) throws IOException
	{
		String gender;
		double sal, da, hra, pf, gross, net;
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		System.out.println("Enter gender of emp.: ");
		gender = br.readLine();
		System.out.println("Enter salary: ");
		sal = Double.parseDouble(br.readLine());
		if ( gender.equals("female") || gender.equals("FEMALE") && sal>=5000)
		{
			hra = sal * 0.15;
			da = sal * 0.10;
			pf = sal * 0.08;
		}
		else if (gender.equals("male") || gender.equals("MALE") && sal>=5000)
		{
			hra = sal * 0.20;
			da = sal * 0.15;
			pf = sal * 0.10;
		}
		else
		{
			hra = sal * 0.10;
			da = sal * 0.09;
			pf = sal * 0.08;
		}
		gross = sal+da+hra;
		net = gross - pf;
		System.out.println("Gross salary : " + gross);
		System.out.println("Net Salary : " +net);
	}
}