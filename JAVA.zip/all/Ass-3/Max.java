import java.io.*;
class Max
{
	public static void main(String args[]) throws IOException
	{
		int a,b;
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		System.out.println("Enter first Number: ");
		a = Integer.parseInt(br.readLine());
		b = Integer.parseInt(br.readLine());
		if (a > b )
			System.out.println(a + " is Max.");
		else
			System.out.println(b + " is Max.");
	}
}