import java.io.*;
class Bill
{
	public static void main(String args[]) throws IOException
	{
		double sr, er, unit, total;
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		System.out.println("Enter start reading: ");
		sr = Double.parseDouble(br.readLine());
		System.out.println("Enter end reading: ");
		er = Double.parseDouble(br.readLine());
		unit = er-sr;
		if (unit < 100)
			total = unit * 1.5;
		else if (unit >=100 && unit <200)
			total = unit * 2.5;
		else if (unit >=200 && unit <=500)
			total = unit * 3.5;
		else
			total = unit *5;
		System.out.println("Total bill payable: " +total);
	}
}