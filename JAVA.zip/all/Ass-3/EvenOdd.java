import java.io.*;
class EvenOdd
{
	public static void main(String args[]) throws IOException
	{
		int a;
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		System.out.println("Enter a Number: ");
		a = Integer.parseInt(br.readLine());
		if (a%2 == 0)
			System.out.println(a + " is Even");
		else
			System.out.println(a + " is Odd.");
	}
}