import java.io.*;
class Largest
{
	public static void main(String args[]) throws IOException
	{
		int a,b,c;
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		System.out.println("Enter 3 Number: ");
		a = Integer.parseInt(br.readLine());
		b = Integer.parseInt(br.readLine());
		c = Integer.parseInt(br.readLine());
		if (a>b && a>c)
			System.out.println(a + " is Largest");
		else if (b>a && b>c)
			System.out.println(b + " is Largest");
		else
			System.out.println(c + " is Largest");
	}
}