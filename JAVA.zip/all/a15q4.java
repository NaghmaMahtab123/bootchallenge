import java.awt.*;
import java.awt.event.*;
public class a15q4 extends java.applet.Applet implements ActionListener
{
	TextField t1,t2;
	int fact=1,m,rev=0,n;
	Button b1,b2,b3;
	String msg;
	Label l1,l2;
	a15q4 e;
	public void init()
	{	e=this;
		t1=new TextField(3);
		t2=new TextField(10);
		b1=new Button("FIND REVERSE");
		l1=new Label("ENTER THE NUMBER");
		l2=new Label("RESULT");
		add(l1);	
		add(t1);
		add(l2);
		add(t2);
		add(b1);
		b1.addActionListener(this);
 
	}
 
	public void actionPerformed(ActionEvent ae)
	{
		String str=t1.getText();
		if(str!="")
		{
		int num=Integer.parseInt(str);
		rev=0;
		while(num!=0)
		{
			n=num%10;
			rev=(rev*10)+n;
			num=num/10;
		}
 
		msg="" +rev;
		t2.setText(msg);
		rev=0;
		//fact=1;
		}
 
	}
}