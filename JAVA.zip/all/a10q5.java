import d1.data.Data;
class Main
{
  public static void main(String args[])
  {
    Data obj=new Data();
    obj.disp();
   }
}