import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*<applet code="fibo.class" height=300 width=400>
</applet>*/
public class fibo extends Applet implements ActionListener
{
  Label l1;
  Label l2;
  TextField t1;
  TextField t2;
  Button b1;
  public void init()
  {
    l1=new Label("Enter the number");
    l2=new Label("Result");
    t1=new TextField(6);
    t2=new TextField(6);
    b1=new Button("CALCULATE");
    add(l1);
    add(t1);
    add(l2);
    add(t2);
    add(b1);
    b1.addActionListener(this);
  }
  public void actionPerformed(ActionEvent ae)
  { 
    int n,n1=0,n2=1,n3,i,s=0;
    n=Integer.parseInt(t1.getText());
    s=n1+n2;
    for(i=3;i<=n;i++)
     {
       n3=n1+n2;
       s=s+n3;
       n1=n2;
       n2=n3;
     } 
    t2.setText(Integer.toString(s));
  }
}