

	/*<applet code="SumApplet.class" width=600 height=200></applet>*/

	import javax.swing.*;
	import java.applet.*;
	import java.awt.*;
	import java.awt.event.*;
	public class SumApplet extends Applet implements ActionListener 
	{
		JTextField input1,input2,output;
		JLabel label1,label2,label3;
		JButton b1;
		JLabel lbl;
		int num1,num2,sum=0;
		public void init()
		{
		label1=new JLabel("Enter first number:");
		add(label1);
		label1.setBackground(Color.yellow);
		label1.setForeground(Color.green);
		input1=new JTextField(5);
		add(input1);
		label2=new JLabel("Enter second number:");
		add(label2);
		label2.setBackground(Color.yellow);
		label2.setForeground(Color.green);
		input2=new JTextField(5);
		add(input2);
		label3=new JLabel("Result:");
		add(label3);
		label3.setBackground(Color.yellow);
		label3.setForeground(Color.green);
		output=new JTextField(8);
		add(output);
		b1=new JButton("Add");
		add(b1);
		b1.addActionListener(this);
		setBackground(Color.yellow);
		}
		public void actionPerformed(ActionEvent ae)
		{
			try
				{
				num1=Integer.parseInt(input1.getText());
				num2=Integer.parseInt(input2.getText());
				sum=num1+num2;
				output.setText(Integer.toString(sum));
				}
			catch(NumberFormatException e)
				{
				lbl.setForeground(Color.red);
				lbl.setText("Invalid Entry");
				}
		}
	}
		
	