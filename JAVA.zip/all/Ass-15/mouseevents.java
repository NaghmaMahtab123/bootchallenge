import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*<applet code="mouseevents.class" height=300 width=400>
</applet>*/
public class mouseevents extends Applet implements MouseListener, MouseMotionListener
{ 
 TextField t1;
 public void init()
  {
    t1=new TextField(30);
    addMouseListener(this);
    addMouseMotionListener(this);
    add(t1);
  }
 public void mouseClicked(MouseEvent me)
 {
  t1.setText("mouse Clicked");
 }

 public void mouseEntered(MouseEvent me)
 {
  t1.setText("mouse Entered");
 }

public void mouseExited(MouseEvent me)
 {
  t1.setText("mouse Exited");
 }
public void mousePressed(MouseEvent me)
 {
  t1.setText("mouse Pressed");
 }
public void mouseReleased(MouseEvent me)
 {
  t1.setText("mouse Released");
 }
public void mouseDragged(MouseEvent me)
 {
  t1.setText("mouse Dragged");
 }
public void mouseMoved(MouseEvent me)
 {
  t1.setText("mouse Moved");
 }
}