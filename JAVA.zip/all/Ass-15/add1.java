import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*<applet code="add1.class" height=300 width=400>
</applet>*/
public class add1 extends Applet implements ActionListener
{
  Label l1;
  Button b1;
  public void init()
  {
    l1=new Label("This is a label");
    b1=new Button("This is a button");
    add(l1);
    add(b1);
  }
  public void actionPerformed(ActionEvent ae){} 
}