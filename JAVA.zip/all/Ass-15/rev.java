import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*<applet code="rev.class" height=300 width=400>
</applet>*/
public class rev extends Applet implements ActionListener
{
  Label l1;
  Label l2;
  TextField t1;
  TextField t2;
  Button b1;
  public void init()
  {
    l1=new Label("Enter the number");
    l2=new Label("Result");
    t1=new TextField(6);
    t2=new TextField(6);
    b1=new Button("CALCULATE");
    add(l1);
    add(t1);
    add(l2);
    add(t2);
    add(b1);
    b1.addActionListener(this);
  }
  public void actionPerformed(ActionEvent ae)
  { 
    int r=0,d,n,i;
    n=Integer.parseInt(t1.getText());
    while(n!=0)
    { 
      d=n%10;
      r=r*10+d;
      n=n/10;
    }
   t2.setText(Integer.toString(r));
  }
}