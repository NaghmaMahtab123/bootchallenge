import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*<applet code="fact.class" height=300 width=400>
</applet>*/
public class fact extends Applet implements ActionListener
{
  Label l1;
  Label l2;
  TextField t1;
  TextField t2;
  Button b1;
  public void init()
  {
    l1=new Label("Enter the number");
    l2=new Label("Result");
    t1=new TextField(6);
    t2=new TextField(6);
    b1=new Button("CALCULATE");
    add(l1);
    add(t1);
    add(l2);
    add(t2);
    add(b1);
    b1.addActionListener(this);
  }
  public void actionPerformed(ActionEvent ae)
  { 
    int f=1,n,i;
    n=Integer.parseInt(t1.getText());
    for(i=1;i<=n;i++)
    { 
      f=f*i;
    }
    t2.setText(Integer.toString(f));
  }
}
