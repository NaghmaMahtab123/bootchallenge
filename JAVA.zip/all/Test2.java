
import java.sql.*;
public class Test2 {
	public static void main(String args[])
	{
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			//String dburl="jdbc:odbc:DSNORACLE";
			Connection conn=DriverManager.getConnection("jdbc:odbc:DSNORACLE","scott","tiger");
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from student");
			while(rs.next())
			{
				System.out.println(rs.getInt("ST_ID"));
				System.out.println(rs.getString("ST_NAME"));
			}
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		
	}
	
}
