package d1.data;
public class Data
{
  public void disp()
  {
    System.out.println("You are in sub package data");
  }
}