import java.io.*;
class Arith
{
  public static void main(String ar[]) throws IOException
  {
	int a,b,res;
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter two numbers:");
	a = Integer.parseInt(br.readLine());
	b = Integer.parseInt(br.readLine());
    try
    {
      res=a/b;
      System.out.println("Result : " + res); 
    }
    catch(ArithmeticException ae)
    {
      System.out.println(ae);
    }
  }
}