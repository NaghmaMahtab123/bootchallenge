class Error3
{
  public static void main(String ar[])
  {
    int a[]={2,3};
    int b=5,res;
    try
    {
      res=a[2]+b;      
    }
    catch(ArrayIndexOutOfBoundsException ae)
    {
      System.out.println(" Array Index Out of Bound Exception ");
    }
    finally
    {
      System.out.println(" Result :"+(a[0]+b));
    }
  }
}