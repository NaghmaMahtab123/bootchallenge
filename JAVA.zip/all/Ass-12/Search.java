import java.io.*;
class Search
{
	public static void main(String args[]) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int a[] = new int[5];
		int pos;
		System.out.println("Enter array elements: ");
		for(int i=0;i<5;i++)
		{
			System.out.println("Element " + (i+1) + ":");
			a[i] = Integer.parseInt(br.readLine());
		}
		System.out.println("Enter position of the element to search: ");
		pos = Integer.parseInt(br.readLine());
		try
		{
			System.out.println("Array element at " + pos +" is : " + a[pos-1]);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
	}
}