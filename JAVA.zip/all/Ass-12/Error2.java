import java.io.*;
class Error2
{
  static void Demo() throws NullPointerException
  {
    try
    {
      throw new NullPointerException("Demo");
    }
    catch(NullPointerException ne)
    {
      System.out.println(" Exception: "+ne);
    }
  }
  public static void main(String ar[])
  {
   Demo();
  }
}