class NegativeException extends Exception
{
	NegativeException()
	{
		System.out.println("Java.SagarAnimikh.: Negative Exception");
	}
	
}
class Subtract
{
	int a, b;
	Subtract (int a1, int b1)
	{
		a = a1;
		b = b1;
	}
	void cal()
	{
		int c;
		try
		{
			if(a>b)
				c = a - b;
			else
				throw new NegativeException();
		}
		catch(NegativeException e)
		{
			System.out.println(e);
		}
	}
}
class EDemo
{
	public static void main(String args[])
	{
		Subtract obj = new Subtract(6,9);
		obj.cal();
	}
}
	