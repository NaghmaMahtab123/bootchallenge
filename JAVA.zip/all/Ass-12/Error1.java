import java.io.*;
class Error1
{
  public static void main(String ar[])
  {
    int a[]={2,3};
    int b=5,res;
    try
    {
      res=a[2]+b;   
    }
    catch(ArrayIndexOutOfBoundsException ae)
    {
	System.out.println(ae);
      //System.out.println(" Array Index Out of Bound Exception ");
    }
  }
}