import java.awt.*;
import java.applet.*;
public class a14q3 extends Applet {
	String s;
public void paint(Graphics g)
{
	g.setColor(Color.blue);
	g.drawString(s,10,50);
}
public void init()
{
	s=getParameter("s");
	if(s==null)
		s="Null value returned";
}
}
